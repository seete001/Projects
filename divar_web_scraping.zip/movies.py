import re
import requests
from bs4 import BeautifulSoup

url = 'https://divar.ir/s/tehran/vehicles'

response = requests.get(url, timeout = 10)

soup = BeautifulSoup(response.text, 'html.parser')

tags = soup.find_all('div', class_="unsafe-kt-post-card__body")


for tag in tags:
    title_tag = tag.find('h2', class_="unsafe-kt-post-card__title")
    title = title_tag.get_text(strip=True) if title_tag else "بدون عنوان"
    price_tag = tag.find('div', class_="unsafe-kt-post-card__description")
    price = price_tag.get_text(strip=True) if price_tag else "بدون قیمت"
    
    if price == 'توافقی':
        print(f"{title} >>>>>>> {price}")
    